package de.hgs.itg23.scheduler.model;

public class Scheduler {

}
