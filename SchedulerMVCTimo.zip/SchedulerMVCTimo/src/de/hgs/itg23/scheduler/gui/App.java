package de.hgs.itg23.scheduler.gui;

public class App {

	public static void main(String[] args) {
		
		View v = new View();
		v.setVisible(true);
		
	}

}
