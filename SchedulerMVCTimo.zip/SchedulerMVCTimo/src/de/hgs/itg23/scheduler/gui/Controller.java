package de.hgs.itg23.scheduler.gui;

public class Controller {

}
